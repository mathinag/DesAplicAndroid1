package mathi.nag.desapandroidsemana2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Calendar;

public class MostrarDatos extends AppCompatActivity {
    private TextView tvNombre;
    private TextView tvTelefono;
    private TextView tvemail;
    private TextView tvDescripcionContacto;
    private TextView tvmDisplayDate;
    private Button btnRegresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_datos);

        Bundle parametros = getIntent().getExtras();

        String Snombre = parametros.getString("nombre");
        String Stelefono = parametros.getString("telefono");
        String Semail = parametros.getString("email"); //recibe el parametro email
        String SdescripcionContacto = parametros.getString("descripcion"); //recibe el parametro
        String SmostrarFecha = parametros.getString("fecha"); //recibe el parametro

        //se declaran los textViews
        tvNombre = (TextView) findViewById(R.id.editTextTextPersonName);
        tvTelefono = (TextView) findViewById(R.id.Telefono);
        tvemail = (TextView) findViewById(R.id.editTextTextEmail);
        tvDescripcionContacto = (TextView) findViewById(R.id.DescripcionContacto);
        tvmDisplayDate = (TextView) findViewById(R.id.mDisplayDate);

        tvNombre.setText("Nombre: " + Snombre);
        tvTelefono.setText("Teléfono: " + Stelefono);
        tvemail.setText("Email: " + Semail);
        tvDescripcionContacto.setText("Descripción: " + SdescripcionContacto);
        tvmDisplayDate.setText("Fecha de Nacimiento: " + SmostrarFecha);


        btnRegresar = (Button) findViewById(R.id.Regresar);
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
