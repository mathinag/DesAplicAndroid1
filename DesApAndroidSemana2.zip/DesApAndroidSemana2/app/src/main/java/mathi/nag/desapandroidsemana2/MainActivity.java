package mathi.nag.desapandroidsemana2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private TextView mDisplayDate;
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button btnBoton;

    private EditText tvNombre2;
    private EditText tvTelefono2;
    private EditText tvemail2;
    private EditText tvDescripcionContacto2;
    private TextView tvmDisplayDate2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText editTextTextPersonName = (EditText) findViewById(R.id.editTextTextPersonName);
        final EditText telefono = (EditText) findViewById(R.id.Telefono);
        final EditText editTextTextEmail = (EditText) findViewById(R.id.editTextTextEmail);
        final EditText DescripcionContacto = (EditText) findViewById(R.id.DescripcionContacto);
        final TextView mDisplayDate = (TextView) findViewById(R.id.mDisplayDate);


        mDisplayDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //crea una nueva instancia en el evento onClick y toma el año, mes y dia
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                       MainActivity.this,
                       android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year, month, day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });

        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
               month = month + 1;
                Log.d(TAG, "onDateSet: dd/mm/yyyy: " + day + "/" + month + "/" + year);

                String date = day + "/" + month + "/" + year;
                mDisplayDate.setText(date);
           }
        };



        btnBoton = findViewById(R.id.btnMiBoton2);
        btnBoton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, MostrarDatos.class);
                intent.putExtra("nombre", editTextTextPersonName.getText().toString());
                intent.putExtra("telefono", telefono.getText().toString());
                intent.putExtra("email",  editTextTextEmail.getText().toString());
                intent.putExtra("descripcion",  DescripcionContacto.getText().toString());
                intent.putExtra("fecha", mDisplayDate.getText().toString());

                startActivity(intent);

            }
        });

    }
}
